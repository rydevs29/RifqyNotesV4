// File: api/summarize.js

import { createClient } from '@vercel/kv'; // Contoh jika pakai Vercel KV, tapi kita pakai env var
// Kode ini berjalan di server Vercel, bukan di browser user

export default async function handler(req, res) {
    // Hanya izinkan request POST
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method Not Allowed' });
    }

    const { text } = req.body;

    if (!text) {
        return res.status(400).json({ error: 'Text is required' });
    }

    // API Key disimpan dengan aman di Environment Variables Vercel
    const API_KEY = process.env.OPENAI_API_KEY;

    if (!API_KEY) {
        return res.status(500).json({ error: 'API Key is not configured on the server.' });
    }

    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [{ role: "user", content: `Jadilah asisten yang merangkum. Buat ringkasan singkat dari teks berikut dalam bahasa Indonesia: "${text}"` }],
                max_tokens: 100
            })
        });

        const data = await response.json();
        const summary = data.choices[0].message.content.trim();

        res.status(200).json({ summary });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to summarize text.' });
    }
}// File: api/summarize.js

import { createClient } from '@vercel/kv'; // Contoh jika pakai Vercel KV, tapi kita pakai env var
// Kode ini berjalan di server Vercel, bukan di browser user

export default async function handler(req, res) {
    // Hanya izinkan request POST
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method Not Allowed' });
    }

    const { text } = req.body;

    if (!text) {
        return res.status(400).json({ error: 'Text is required' });
    }

    // API Key disimpan dengan aman di Environment Variables Vercel
    const API_KEY = process.env.OPENAI_API_KEY;

    if (!API_KEY) {
        return res.status(500).json({ error: 'API Key is not configured on the server.' });
    }

    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [{ role: "user", content: `Jadilah asisten yang merangkum. Buat ringkasan singkat dari teks berikut dalam bahasa Indonesia: "${text}"` }],
                max_tokens: 100
            })
        });

        const data = await response.json();
        const summary = data.choices[0].message.content.trim();

        res.status(200).json({ summary });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to summarize text.' });
    }
}// File: api/summarize.js

import { createClient } from '@vercel/kv'; // Contoh jika pakai Vercel KV, tapi kita pakai env var
// Kode ini berjalan di server Vercel, bukan di browser user

export default async function handler(req, res) {
    // Hanya izinkan request POST
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method Not Allowed' });
    }

    const { text } = req.body;

    if (!text) {
        return res.status(400).json({ error: 'Text is required' });
    }

    // API Key disimpan dengan aman di Environment Variables Vercel
    const API_KEY = process.env.OPENAI_API_KEY;

    if (!API_KEY) {
        return res.status(500).json({ error: 'API Key is not configured on the server.' });
    }

    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [{ role: "user", content: `Jadilah asisten yang merangkum. Buat ringkasan singkat dari teks berikut dalam bahasa Indonesia: "${text}"` }],
                max_tokens: 100
            })
        });

        const data = await response.json();
        const summary = data.choices[0].message.content.trim();

        res.status(200).json({ summary });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to summarize text.' });
    }
}